package com.rick.contacto;

import java.io.Serializable;

public class Contacto implements Serializable {

    private String nombre;
    private String fecha;
    private String tel;
    private String correo;
    private String desc;

    public Contacto(String nombre, String fecha,String tel, String correo, String desc) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.tel = tel;
        this.correo = correo;
        this.desc = desc;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getNombre() {
        return nombre;
    }

    public String getFecha() {
        return fecha;
    }

    public String getTel() {
        return tel;
    }

    public String getCorreo() {
        return correo;
    }

    public String getDesc() {
        return desc;
    }


}
