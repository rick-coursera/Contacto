package com.rick.contacto;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Objects;

//import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity {

    TextView fecha;
    EditText nombre,tel,correo,desc;
    DatePickerDialog.OnDateSetListener dateListener;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fecha = findViewById(R.id.fecha);
        Calendar calendario = Calendar.getInstance();
        final int anio = calendario.get(Calendar.YEAR);
        final int mes = calendario.get(Calendar.MONTH);
        final int dia = calendario.get(Calendar.DAY_OF_MONTH);

        //SimpleDateFormat stringFecha = new SimpleDateFormat("dd/MM/yyyy");

        fecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog dataPicker = new DatePickerDialog(MainActivity.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        dateListener, anio, mes,dia);
                Objects.requireNonNull(dataPicker.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dataPicker.show();
            }
        });

        dateListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int anio, int mes, int dia) {
                mes = mes + 1;
                String strFecha = dia +"/"+ mes  +"/"+ anio;
                fecha.setText(strFecha);
            }
        };

        Button btnEnviar = (Button) findViewById(R.id.btn_siguiente);

        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                nombre = (EditText) findViewById(R.id.nombre);
                fecha = (TextView) findViewById(R.id.fecha);
                tel = (EditText) findViewById(R.id.telefono);
                correo =  (EditText) findViewById(R.id.correo);
                desc =  (EditText) findViewById(R.id.desc);

                Contacto contacto = new Contacto(nombre.getText().toString(),
                        fecha.getText().toString(),
                        tel.getText().toString(),
                        correo.getText().toString(),
                        desc.getText().toString());

                Bundle datos = new Bundle();
                datos.putSerializable("datos",contacto);

                Intent enviar = new Intent(MainActivity.this, InfoActivity.class);
                enviar.putExtras(datos);
                Toast.makeText(getApplicationContext(),"Solicitud en proceso",Toast.LENGTH_LONG).show();
                startActivity(enviar);

            }
        });

    }
}