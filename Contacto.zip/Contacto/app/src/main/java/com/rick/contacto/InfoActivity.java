package com.rick.contacto;

import android.arch.lifecycle.ViewModelStoreOwner;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class InfoActivity extends AppCompatActivity {

    TextView nombre,fecha,telefono,correo,desc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        nombre = (TextView) findViewById(R.id.nombre);
        fecha = (TextView) findViewById(R.id.fecha);
        telefono = (TextView) findViewById(R.id.telefono);
        correo = (TextView)findViewById(R.id.correo);
        desc = (TextView) findViewById(R.id.desc);

        Bundle objEnviado = getIntent().getExtras();
        Contacto contacto=null;
        contacto = (Contacto) objEnviado.getSerializable("datos");

        //Toast.makeText(getApplicationContext(),contacto.getNombre().toString(),Toast.LENGTH_LONG).show();

        if(objEnviado!=null){

            nombre.setText(contacto.getNombre().toString());

            fecha.setText(contacto.getFecha().toString());
            telefono.setText(contacto.getTel().toString());
            correo.setText(contacto.getCorreo().toString());
            desc.setText(contacto.getDesc().toString());
        }

    }



    public void editar(View vst){
        finish();
    }
}